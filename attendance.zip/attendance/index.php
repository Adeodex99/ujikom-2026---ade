<html>
<body>
<?php session_start(); ?> 


<?php include("dbcon.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="tableExport.js"></script>
<script type="text/javascript" src="jquery.base64.js"></script>
<script type="text/javascript" src="html2canvas.js"></script>
<script type="text/javascript" src="jspdf/libs/sprintf.js"></script>
<script type="text/javascript" src="jspdf/jspdf.js"></script>
<script type="text/javascript" src="jspdf/libs/base64.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<form style="margin-left: 10px;" method="POST" action ="<?php echo $_SERVER["PHP_SELF"];?>" >
 <h1>ATTENDANCE SYSTEM</h1>
<input type="text" name="year" placeholder="RF ID" size="48">
<input type="text" style="height:8%;width:10%;border:0px;color:white;background-color:rgba(204, 204, 204, 0);" size="48" value="DATE:FROM"  readonly >
<input type="date" style="height:8%;" name="date1" placeholder="frist date" size="48">
<input type="text" style="height:8%;width:5%;border:0px;color:white;background-color:rgba(204, 204, 204, 0);" size="48" value="To"  readonly >
<input style="height:8%;" type="date" name="date2" placeholder="last date" size="48">
<input type="text" name="clg"  placeholder="ENTER CLASS" size="48">

 

<input type="submit" style="margin-right: 10px;float: right;margin-top: 1%;margin-right: 3.3%" value="SUBMIT">


</form><button style="margin-left: 10px;float: left;margin-top: -10;"   id="btPrint" onclick="createPDF()">REPORT PDF</button>
<a href="projectdetails.php"><button style="margin-left: 30px;float: left;margin-top: -10;width: 12%;" >ADD STUDENTS</button></a>

<section style"margin-left: 0px; margin-right: 0px;margin-top: 0px;">
  <!--for demo wrap-->


  <div class="tbl-header" id="tab">
    <table style=" width: 100%;" cellpadding="0" cellspacing="0" border="0">
	
      <thead style=" background-color: orangered;">
            <tr>
			<th ><font>RF ID</font></th>
          <th ><font > Name</font></th>
           <th ><font >CLASS</font></th>
		   <th ><font >DATE</font></th>
          <th ><font >TIME</font></th>
           
          
				 	 
			 
            </tr>
          </thead>
  

   
      <tbody>
	  <?php if ($_SERVER["REQUEST_METHOD"] != "POST") {

 
	$result = mysqli_query($db,"select * from students ");
	
	
	if(mysqli_num_rows($result)>0)
	
{  while($row = mysqli_fetch_assoc($result))
{
?>
            <tr>
			<td>
               <?php echo $row["rf"];?> </td>
              
              <td>
               <?php echo $row["name"];?> </td>
              <td>
              <?php echo $row["class"];?></td>
              <td>
                 <?php echo date('d/m/Y',strtotime($row["date"]));?></td>
				<td>
              <?php echo $row["time"];?> </td>
              
            </tr>
	  <?php }}} ?>
	  
	  
	  <?php if ($_SERVER["REQUEST_METHOD"] == "POST") {
		  $year = $_POST["year"];
		  $date1 =date('d-m-Y',strtotime($_POST["date1"]));
		  $date2 = date('d-m-Y',strtotime($_POST["date2"]));
		  $clg = $_POST["clg"];
		 if($date1=="01-01-1970")
		 {
			 $date1=0;
		 }
		  if($date2=="01-01-1970")
		 {
			 $date2=0;
		 }
		  //echo $date1;   echo $date1;
		  if(!empty($year)){$y="rf='$year'";}else{$y="1";}
		  if(!empty($date1)){if(!empty($date2)){$d="date BETWEEN '$date1' AND '$date2'";}else{$d="1";}}else{$d="1";}
		  if(!empty($date1)){if(empty($date2)){$d1="date= '$date1'";}else{$d1="1";}}else{$d1="1";}

		  
		  if(!empty($clg)){$c="class='$clg'";}else{$c="1";}
		 


	  $query = "select * from students where  $y  and $d and $d1 and  $c "; //search with a book name in the table book_info
 
	$result = mysqli_query($db, $query );
	
	
	if(mysqli_num_rows($result)>0)
	
{  while($row = mysqli_fetch_assoc($result))
{
?>
            <tr>
			<td>
               <?php echo $row["rf"];?> </td>
              
              <td>
               <?php echo $row["name"];?> </td>
              <td>
              <?php echo $row["class"];?></td>
              <td>
                 <?php echo date('d/m/Y',strtotime($row["date"]));?></td>
				<td>
              <?php echo $row["time"];?> </td>
              
				 
            </tr>
<?php }}} ?>
	  
	  
	  
              
 </tbody>
    </table>
  </div>
</section>
</body>
</html>

<!-- follow me template -->


 <style>
h1{
  font-size: 30px;
  color: #fff;
  text-transform: uppercase;
  font-weight: 300;
  text-align: center;
  margin-bottom: 15px;
}
table{
  width:100%;
  table-layout: fixed;
}
.tbl-header{
  background-color: rgb(39 5 78);
 }
.tbl-content{
  height:300px;
  overflow-x:auto;
  margin-top: 0px;
  border: 1px solid rgba(255,255,255,0.3);
}

th{
  padding: 20px 15px;
  text-align: left;
  font-weight: 500;
  font-size: 12px;
  color: #fff;
  text-transform: uppercase;
}
td{
  padding: 15px;
  text-align: left;
  vertical-align:middle;
  font-weight: 300;
  font-size: 12px;
  color: #fff;
  border-bottom: solid 1px rgba(255,255,255,0.1);
}

::placeholder {
    color: red;
    opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
   color: red;
}

::-ms-input-placeholder { /* Microsoft Edge */
   color: red;
}
/* demo styles */

@import url(https://fonts.googleapis.com/css?family=Roboto:400,500,300,700);
body{
  background: -webkit-linear-gradient(left, #25c481, #25b7c4);
  background: linear-gradient(to right, #3c0d39, #250450);
  font-family: 'Roboto', sans-serif;
}
section{
  margin: 50px;
}


/* follow me template */
.made-with-love {
  margin-top: 40px;
  padding: 10px;
  clear: left;
  text-align: center;
  font-size: 10px;
  font-family: arial;
  color: #fff;
}
.made-with-love i {
  font-style: normal;
  color: #F50057;
  font-size: 14px;
  position: relative;
  top: 2px;
}
.made-with-love a {
  color: #fff;
  text-decoration: none;
}
.made-with-love a:hover {
  text-decoration: underline;
}

input[type=submit] {
    width: 10%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
button {
    width: 10%;
    background-color: #dc45d0;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type=text],select,input[type=number],input[type=date]{
    width: 16%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
	
}


/* for custom scrollbar for webkit browser*/

::-webkit-scrollbar {
    width: 6px;
} 
::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
} 
::-webkit-scrollbar-thumb {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
}</style>
<script>
// '.tbl-content' consumed little space for vertical scrollbar, scrollbar width depend on browser/os/platfrom. Here calculate the scollbar width .
$(window).on("load resize ", function() {
  var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
  $('.tbl-header').css({'padding-right':scrollWidth});
}).resize();

</script>

<script>
function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.pdf':'excel_data.pdf';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}


</script>
<script>
    function createPDF() {
        var sTable = document.getElementById('tab').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
		 style = style + "thead {background-color: orangered;color: #FFF}";
		 style = style + "table, th,td {border: solid 1px #000;border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>ATTENDANCE</title>');   // <title> FOR PDF HEADER.
        win.document.write(style);          // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable);         // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close();   // CLOSE THE CURRENT WINDOW.

        win.print();    // PRINT THE CONTENTS.
    }
</script>
