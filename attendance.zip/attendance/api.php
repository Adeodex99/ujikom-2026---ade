<?php
//header("content-type:json");
$con=mysqli_connect("localhost","root","","movie");
if($con)
{
	//echo"DB connected";
	$sql=mysqli_query($con,"select * from holly WHERE id = '".$_GET["id"]."'");
	if($sql)
	{
		$i=0;
		while($row=mysqli_fetch_assoc($sql))
		{
			$respones['id']=$row['id'];
			$respones['name']=$row['name'];
			$respones['rf']=$row['rf'];
			$respones['mname']=$row['mname'];
			$i++;
		}
		echo json_encode($respones);
	}
}
else
{
		echo"DB connected FAIL";
}


?>