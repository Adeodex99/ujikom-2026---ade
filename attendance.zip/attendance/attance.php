<?php
//header("content-type:json");
$con=mysqli_connect("localhost","root","","attance");
if($con)
{
	//echo"DB connected";
	$sql=mysqli_query($con,"select * from rfname WHERE rf = '".$_GET["rf"]."'");
	if($sql)
	{
		$i=0;
		while($row=mysqli_fetch_assoc($sql))
		{
			
			$respones['name']=$row['name'];
			
			
		}
		echo $respones['name'];
	}
}
else
{
		echo"DB connected FAIL";
}


?>