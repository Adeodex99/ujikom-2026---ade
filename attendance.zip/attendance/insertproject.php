<?php 
include("dbcon.php");
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
     $name=$_POST['name'];
     $rf=$_POST['rf'];
     $class=$_POST['class'];
	
	
     

   $sql= mysqli_query($db,"insert into students(name,class,rf)
         values('$name','$class','$rf')");
  if($sql)
  {
	 ?><script>

    alert("Sucessfully Insert Data");
document.location.href = 'index.php';
</script><?php
  }
else
{
	echo"not";
}
   }
   ?>