<?php include("dbcon.php"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<div class="login-page">
    <div class="form">
        <form class="register-form forms" action="insertproject.php" method="post"><center>STUDENTS DETAILS</center>
            <input name="name" type="text" placeholder=" NAME" />
			<input name="rf" type="text" placeholder=" RF ID" />
			<input name="class" type="text" placeholder=" CLASS" />
           
		    <button type="submit">SUBMIT</button>
            
        </form>
         <a href="index.php"><button>BACK</button></a>
    </div>
</div>
<style>


body {
  font-size: 1rem;
  line-height: 1.5;
  font-family: 'Lato', sans-serif;
  background-color: #dedede;
}

.button-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 10px;
}
.button-container button {
  flex: 1;
  border-width: 0;
  outline: none;
  border-radius: 2px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.6);
  background-color: #ff8a16;
  padding: 5px;
}
.button-container form {
  width: 50%;
  justify-self: center;
  text-align: center;
}

.login-page {
  width: 100%;
  padding: 8% 0 0;
  margin: auto;
}

.form {
  position: relative;
  z-index: 1;
  background: #FFFFFF;
  max-width: 100%;
  margin: 0 auto 100px;
  padding: 45px;
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
}

.form input,select {
  font-family: "Lato", sans-serif;
  outline: 0;
  background: #f2f2f2;
  width: 100%;
  border: 0;
  margin: 0 0 15px;
  padding: 15px;
  box-sizing: border-box;
  font-size: 0.875rem;
}

.form input:active {
  background: #fff02;
}

.form button {
  font-family: "Lato", sans-serif;
  text-transform: uppercase;
  outline: 0;
  background-image: linear-gradient(to right, #fbc2eb 0%, #a6c1ee 51%, #fbc2eb 100%);
  width: 100%;
  border: 0;
  padding: 15px;
  color: #FFFFFF;
  background-size: 200% auto;
  font-size: 1rem;
  transition: 0.5s ease;
  box-shadow: 0 0 20px #eee;
  cursor: pointer;
}

.form button:hover, .form button:active, .form button:focus {
  background-position: right center;
}

.form .message {
  margin: 15px 0 0;
  color: #b3b3b3;
  font-size: 12px;
  text-align: center;
}

.form .message a {
  color: #a6c1ee;
  text-decoration: none;
}

button {
  border-width: 1px;
  border-radius: 2rem;
  outline: 0;
}

form.hide {
  display: none;
  transition: all 1s ease;
}

</style>


