<?php
//header("content-type:json");
$con=mysqli_connect("localhost","root","","attance");
if($con)
{
    //$name=$_GET['name'];
    $date=$_GET['date'];
    $time=$_GET['time'];
    $rf=$_GET['rf'];
	$sql=mysqli_query($con,"select * from students WHERE rf = '".$_GET["rf"]."'");
	
	if($sql)
	{
		$i=0;
		while($row=mysqli_fetch_assoc($sql))
		{
				
			$name=$row['name'];
			$class=$row['class'];
		}
	
	
	$query=mysqli_query($con, "insert into  students(rf,name,date,time,class) value('$rf','$name','$date','$time','$class')");

if ($query) {
	
	
		echo $name;
		//echo "Detail has been added";
	}


  }
  else
    {
     echo "<script>alert('Something Went Wrong. Please try again.');</script>";       
    }
}
else
{
		echo"DB connected FAIL";
}


?>